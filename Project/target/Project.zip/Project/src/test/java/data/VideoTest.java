package data;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;



public class VideoTest {

	//Verify title is correct
	@Test
	@DisplayName("Verify title matches input")
	void testTitle() {
		VideoObj movie = new VideoObj("The Crow", 1994, "Alex Proyas");
		assertEquals("The Crow", movie.title());
	}

	//Verify year is correct
	@Test
	@DisplayName("Verify year matches input")
	void testYear() {
		VideoObj movie = new VideoObj("The Crow", 1994, "Alex Proyas");
		assertEquals(1994, movie.year());
	}

	//Verify director is correct
	@Test
	@DisplayName("Verify director matches input")
	void testDirector() {
		VideoObj movie = new VideoObj("The Crow", 1994, "Alex Proyas");
		assertEquals("Alex Proyas", movie.director());
	}

	//Verify title invariants
	@Test
	@DisplayName("Title cannot be null, blank, or empty spaces")
	void titleInvariantsTest() {

	}
}