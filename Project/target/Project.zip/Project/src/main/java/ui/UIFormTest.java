package ui;


/**
 * UIFormTest interfaces
 * 
 * @author Stephen Kim
 *
 */
public interface UIFormTest {
  public boolean run(String input);
}
