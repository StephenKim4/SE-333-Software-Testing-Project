package ui;

/**
 * UIError Interface
 * 
 * @author Stephen Kim
 *
 */
public class UIError extends Error implements UIErrorInterface {
}
