package ui;

/**
 * UIMenuAction interface
 * 
 * @author Stephen Kim
 *
 */
public interface UIMenuAction {
  public void run();
}
