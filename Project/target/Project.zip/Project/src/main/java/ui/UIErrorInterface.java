/**
 * 
 */
package ui;

/**
 * Interface for UIErrors
 * 
 * @author Stephen Kim
 *
 */
public interface UIErrorInterface {

}
