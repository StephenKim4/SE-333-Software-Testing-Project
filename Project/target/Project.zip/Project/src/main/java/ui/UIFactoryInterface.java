/**
 * 
 */
package ui;

/**
 * Interface for UIFactory
 * 
 * @author Stephen Kim
 *
 */
public interface UIFactoryInterface {

	String popup = "popup";
    String textui = "text";
    String UIFormMenuBuilder = "UIFMB";
    String UIFormMenu = "UIFM";
    
	
}
